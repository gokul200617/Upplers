import os
import json
import argparse
from collections import defaultdict

import torch
from transformers import AutoTokenizer, AutoModelForCausalLM
from peft import PeftModel
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import plotly.graph_objects as go

# Assuming VibeInferenceController or a similar inference logic is available
# from inference.generate import VibeInferenceController 
# For simplicity, we'll create a minimalistic inference utility here.

class SimpleModelInference:
    """
    A simplified class for generating responses from a loaded model.
    Assumes the model is either a full AutoModelForCausalLM or a PEFT model.
    """
    def __init__(self, model_path: str, tokenizer_path: str, device: str):
        self.device = device
        self.tokenizer = AutoTokenizer.from_pretrained(tokenizer_path)
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token
        
        print(f"Loading model from {model_path} for inference...")
        base_model = AutoModelForCausalLM.from_pretrained(
            model_path,
            torch_dtype=torch.bfloat16 if torch.cuda.is_available() else torch.float32
        ).to(self.device)

        try:
            if os.path.exists(os.path.join(model_path, "adapter_config.json")):
                self.model = PeftModel.from_pretrained(base_model, model_path).to(self.device)
                print(f"Loaded {model_path} as PEFT adapter.")
            else:
                self.model = base_model
                print(f"Loaded {model_path} as full model.")
        except Exception as e:
            print(f"Could not load {model_path} as PEFT adapter: {e}. Loading as full model.")
            self.model = base_model

        self.model.eval()

    @torch.no_grad()
    def generate(self, prompt: str, max_new_tokens: int = 100, temperature: float = 0.7, top_k: int = 50, top_p: float = 0.95) -> str:
        inputs = self.tokenizer(prompt, return_tensors="pt").to(self.device)
        outputs = self.model.generate(
            **inputs,
            max_new_tokens=max_new_tokens,
            do_sample=True,
            temperature=temperature,
            top_k=top_k,
            top_p=top_p,
            pad_token_id=self.tokenizer.pad_token_id,
            eos_token_id=self.tokenizer.eos_token_id,
        )
        # Decode only the newly generated tokens
        response_text = self.tokenizer.decode(outputs[0][inputs["input_ids"].shape[1]:], skip_special_tokens=True)
        return response_text


# --- Mock EQ-Bench Scoring ---
def calculate_empathy_score(generated_response: str, ideal_response: str) -> float:
    """
    Mocks an empathy score calculation. A real EQ-Bench 3 would use a sophisticated NLP model
    or human evaluators to score empathy. This is a heuristic-based simulation.
    Scores are between 0 and 1, where 1 is perfectly empathetic.
    """
    score = 0.0
    generated_lower = generated_response.lower()
    ideal_lower = ideal_response.lower()

    # Keywords indicating empathy
    empathy_keywords = [
        "i understand", "i'm sorry to hear that", "it sounds like", "i get that",
        "it's okay to feel", "i'm here for you", "that must be difficult",
        "i can imagine how you feel", "valid feeling", "i totally get it"
    ]

    # Negative keywords indicating lack of empathy or directiveness
    negative_keywords = [
        "you should", "just forget it", "don't worry", "cheer up",
        "that's not so bad", "get over it", "i told you so"
    ]

    # Score based on presence of empathetic keywords
    for keyword in empathy_keywords:
        if keyword in generated_lower:
            score += 0.1 # Accumulate points for empathy
    
    # Penalize for negative keywords
    for keyword in negative_keywords:
        if keyword in generated_lower:
            score -= 0.2 # Deduct points for negative sentiment

    # Reward for length and similarity to ideal (simple proxy for content richness)
    len_diff = abs(len(generated_response) - len(ideal_response)) / max(len(generated_response), len(ideal_response), 1)
    score += (1 - len_diff) * 0.2 # Reward for similar length

    # Clamp score between 0 and 1
    return max(0.0, min(1.0, score))


def calculate_elo_rating(player_rating, opponent_rating, outcome, k_factor=32):
    """
    Calculates Elo rating update. Outcome: 1 for win, 0 for loss, 0.5 for draw.
    """
    expected_outcome = 1 / (1 + 10**((opponent_rating - player_rating) / 400))
    new_rating = player_rating + k_factor * (outcome - expected_outcome)
    return new_rating

def run_eqbench_evaluation(base_model_path: str, sft_model_path: str, dpo_model_path: str, 
                           tokenizer_path: str, eqbench_data_path: str, output_dir: str):
    
    device = "cuda" if torch.cuda.is_available() else "cpu"

    # Load models
    print("Loading base model...")
    base_model = SimpleModelInference(base_model_path, tokenizer_path, device)
    print("Loading SFT model...")
    sft_model = SimpleModelInference(sft_model_path, tokenizer_path, device)
    print("Loading SFT+DPO model...")
    dpo_model = SimpleModelInference(dpo_model_path, tokenizer_path, device)

    models = {
        "Base": base_model,
        "SFT": sft_model,
        "SFT+DPO": dpo_model,
    }
    
    # Load EQ-Bench dataset
    eqbench_data = []
    with open(eqbench_data_path, "r", encoding="utf-8") as f:
        for line in f:
            eqbench_data.append(json.loads(line))
    
    results = defaultdict(list)
    elo_ratings = {"Base": 1500, "SFT": 1500, "SFT+DPO": 1500}
    k_factor = 32 # Elo rating K-factor

    print("Running EQ-Bench evaluation...")
    for i, item in tqdm(enumerate(eqbench_data), total=len(eqbench_data), desc="Evaluating models"):
        context = item["context"]
        ideal_response = item["ideal_empathetic_response"]

        model_responses = {}
        for model_name, model_inference in models.items():
            model_responses[model_name] = model_inference.generate(f"User: {context}\nAssistant:", max_new_tokens=100)
            # Mock internal reflection as part of generation for consistency
            # This is simplified; true reflection would involve VibeInferenceController logic
            model_responses[model_name] = model_responses[model_name].replace("<tone:warm><persona:best_friend>", "").strip()

        # Calculate raw empathy scores
        for model_name, response in model_responses.items():
            score = calculate_empathy_score(response, ideal_response)
            results[f"{model_name}_raw_score"].append(score)
            results["context"].append(context if model_name == "Base" else "") # Store once per context
            results["model_name"].append(model_name)
            results["generated_response"].append(response)
            results["ideal_response"].append(ideal_response if model_name == "Base" else "")

        # Mock pairwise comparisons for ELO rating updates
        # SFT vs Base
        sft_wins = calculate_empathy_score(model_responses["SFT"], ideal_response) > calculate_empathy_score(model_responses["Base"], ideal_response)
        elo_ratings["SFT"] = calculate_elo_rating(elo_ratings["SFT"], elo_ratings["Base"], 1 if sft_wins else 0, k_factor)
        elo_ratings["Base"] = calculate_elo_rating(elo_ratings["Base"], elo_ratings["SFT"], 0 if sft_wins else 1, k_factor)

        # SFT+DPO vs SFT
        dpo_wins = calculate_empathy_score(model_responses["SFT+DPO"], ideal_response) > calculate_empathy_score(model_responses["SFT"], ideal_response)
        elo_ratings["SFT+DPO"] = calculate_elo_rating(elo_ratings["SFT+DPO"], elo_ratings["SFT"], 1 if dpo_wins else 0, k_factor)
        elo_ratings["SFT"] = calculate_elo_rating(elo_ratings["SFT"], elo_ratings["SFT+DPO"], 0 if dpo_wins else 1, k_factor)

        # SFT+DPO vs Base
        dpo_vs_base_wins = calculate_empathy_score(model_responses["SFT+DPO"], ideal_response) > calculate_empathy_score(model_responses["Base"], ideal_response)
        elo_ratings["SFT+DPO"] = calculate_elo_rating(elo_ratings["SFT+DPO"], elo_ratings["Base"], 1 if dpo_vs_base_wins else 0, k_factor)
        elo_ratings["Base"] = calculate_elo_rating(elo_ratings["Base"], elo_ratings["SFT+DPO"], 0 if dpo_vs_base_wins else 1, k_factor)


    # Aggregate results into a DataFrame
    df = pd.DataFrame(results)
    df_agg = df.groupby("model_name")["generated_response"].apply(list).reset_index()
    df_agg["raw_score_avg"] = df.groupby("model_name")[f"{model_name}_raw_score"].mean()


    # Calculate normalized scores (simple min-max scaling for demonstration)
    for model_name in models.keys():
        raw_scores = results[f"{model_name}_raw_score"]
        min_score, max_score = min(raw_scores), max(raw_scores)
        if (max_score - min_score) > 0:
            normalized_scores = [(s - min_score) / (max_score - min_score) for s in raw_scores]
        else:
            normalized_scores = [0.0] * len(raw_scores)
        results[f"{model_name}_normalized_score"] = normalized_scores
    
    # Store average raw and normalized scores
    summary_data = []
    for model_name in models.keys():
        avg_raw = np.mean(results[f"{model_name}_raw_score"])
        avg_normalized = np.mean(results[f"{model_name}_normalized_score"])
        summary_data.append({"Model": model_name, "Avg Raw Score": avg_raw, "Avg Normalized Score": avg_normalized})

    summary_df = pd.DataFrame(summary_data)
    summary_df["ELO Score"] = summary_df["Model"].map(elo_ratings)
    print("\n--- EQ-Bench 3 Evaluation Summary ---")
    print(summary_df.to_markdown(index=False))

    # Save results
    os.makedirs(output_dir, exist_ok=True)
    summary_df.to_csv(os.path.join(output_dir, "eqbench_summary.csv"), index=False)
    df.to_csv(os.path.join(output_dir, "eqbench_detailed_results.csv"), index=False)
    print(f"Evaluation results saved to {output_dir}")

    # --- Generate Graphs ---
    # Bar chart for Raw and Normalized Scores
    fig = go.Figure(data=[
        go.Bar(name='Avg Raw Score', x=summary_df['Model'], y=summary_df['Avg Raw Score']),
        go.Bar(name='Avg Normalized Score', x=summary_df['Model'], y=summary_df['Avg Normalized Score'])
    ])
    fig.update_layout(barmode='group', title='Average Empathy Scores (Raw and Normalized)', yaxis_title='Score')
    fig.write_html(os.path.join(output_dir, "empathy_scores_bar_chart.html"))
    print(f"Empathy scores bar chart saved to {os.path.join(output_dir, 'empathy_scores_bar_chart.html')}")

    # Bar chart for ELO Scores
    fig_elo = go.Figure(data=[
        go.Bar(name='ELO Score', x=summary_df['Model'], y=summary_df['ELO Score'], marker_color='lightseagreen')
    ])
    fig_elo.update_layout(title='ELO Ratings on EQ-Bench', yaxis_title='ELO Score')
    fig_elo.write_html(os.path.join(output_dir, "elo_ratings_bar_chart.html"))
    print(f"ELO ratings bar chart saved to {os.path.join(output_dir, 'elo_ratings_bar_chart.html')}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Run EQ-Bench 3 evaluation for Vibe AI Chatbot models.")
    parser.add_argument("--base_model_path", type=str, default="distilbert/distilgpt2",
                        help="Path to the base model.")
    parser.add_argument("--sft_model_path", type=str, default="sft_checkpoints/final_model",
                        help="Path to the SFT-trained model checkpoint.")
    parser.add_argument("--dpo_model_path", type=str, default="dpo_checkpoints/final_dpo_model",
                        help="Path to the DPO-trained model checkpoint.")
    parser.add_argument("--tokenizer_path", type=str, default="distilbert/distilgpt2",
                        help="Path to the tokenizer.")
    parser.add_argument("--eqbench_data_path", type=str, default="data/eq_bench_dataset.jsonl",
                        help="Path to the EQ-Bench 3 dataset JSONL file.")
    parser.add_argument("--output_dir", type=str, default="evaluation_results",
                        help="Directory to save evaluation results and graphs.")
    args = parser.parse_args()

    run_eqbench_evaluation(
        base_model_path=args.base_model_path,
        sft_model_path=args.sft_model_path,
        dpo_model_path=args.dpo_model_path,
        tokenizer_path=args.tokenizer_path,
        eqbench_data_path=args.eqbench_data_path,
        output_dir=args.output_dir
    )
