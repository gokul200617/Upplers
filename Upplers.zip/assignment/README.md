# Vibe AI Empathetic Chatbot

This project implements an empathetic, best-friend-style chatbot by fine-tuning a large language model using QLoRA. The goal is to achieve measurable improvements on EQ-Bench 3.

## Project Structure

- `data/`: Contains scripts for dataset preparation and processed data.
- `model/`: Defines the model architecture with auxiliary heads.
- `training/`: Houses the SFT and DPO training scripts.
- `safety/`: Contains the safety teacher model.
- `inference/`: Scripts for generating empathetic responses.
- `evaluation/`: Tools for evaluating model performance, including EQ-Bench.
- `report/`: Generated project report and documentation.
- `config/`: Configuration files for training and inference.
- `outputs/`: Contains all final results, including EQ-Bench evaluation, ablation studies, qualitative examples, safety tests, and stretch ideas.

## Setup

1. **Clone the repository:**
   ```bash
   git clone <repository_url>
   cd vibe-ai-chatbot
   ```

2. **Create a virtual environment and activate it:**
   ```bash
   python -m venv venv
   source venv/bin/activate # On Windows, use `venv\Scripts\activate`
   ```

3. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

## Running the Project

### Data Processing

To download, preprocess, and unify the datasets:

```bash
python data/prepare_datasets.py
```

This will generate `data/unified_dataset.jsonl` and create train/dev splits.

### Supervised Fine-tuning (SFT)

To train the model with Multi-Objective SFT:

```bash
python training/train_sft.py --config_path config/sft_config.json
```

### Direct Preference Optimization (DPO)

To train the model with DPO (after SFT):

```bash
python training/train_dpo.py --config_path config/dpo_config.json
```

### Evaluation

To run the EQ-Bench evaluation:

```bash
python evaluation/run_eqbench.py
```

To run ablations:

```bash
python evaluation/ablations.py
```

### Inference

To generate empathetic responses:

```bash
python inference/generate.py
```

## Configuration

- `config/sft_config.json`: Configuration for Supervised Fine-tuning.
- `config/dpo_config.json`: Configuration for Direct Preference Optimization.
