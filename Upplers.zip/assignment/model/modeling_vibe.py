import torch
import torch.nn as nn
from transformers import AutoModelForCausalLM, AutoConfig
from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training

class VibeModel(nn.Module):
    """
    VibeModel extends a base decoder-only language model with auxiliary heads
    for emotion classification, support strategy classification, and
    valence/arousal regression. It integrates QLoRA for efficient fine-tuning.
    """
    def __init__(self, 
                 model_name: str, 
                 num_emotion_labels: int, 
                 num_strategy_labels: int,
                 quantization_config=None):
        super().__init__()
        
        # Load base model config
        self.config = AutoConfig.from_pretrained(model_name)
        
        # Load base decoder model
        if quantization_config:
            print(f"Loading base model {model_name} with 4-bit quantization...")
            self.base_model = AutoModelForCausalLM.from_pretrained(
                model_name,
                config=self.config,
                quantization_config=quantization_config,
                torch_dtype=torch.bfloat16 # Recommended for QLoRA
            )
            # Prepare model for k-bit training
            self.base_model = prepare_model_for_kbit_training(self.base_model)
        else:
            print(f"Loading base model {model_name} without quantization...")
            self.base_model = AutoModelForCausalLM.from_pretrained(
                model_name,
                config=self.config,
                torch_dtype=torch.bfloat16
            )

        # Ensure LoRA is applied correctly
        lora_config = LoraConfig(
            r=8, # LoRA attention dimension
            lora_alpha=16, # Alpha parameter for LoRA scaling
            target_modules=["q_proj", "v_proj"], # Modules to apply LoRA to
            lora_dropout=0.05, # Dropout probability for LoRA layers
            bias="none", # Only linear layers with `bias=False` are supported for now
            task_type="CAUSAL_LM", # Causal Language Modeling task
        )
        self.base_model = get_peft_model(self.base_model, lora_config)
        self.base_model.print_trainable_parameters() # Print trainable parameters for verification

        # Auxiliary heads
        hidden_size = self.config.hidden_size

        # Emotion head (classification)
        self.emotion_head = nn.Linear(hidden_size, num_emotion_labels)

        # Support strategy head (classification)
        self.strategy_head = nn.Linear(hidden_size, num_strategy_labels)

        # Valence/Arousal head (regression) - optional, for continuous scores
        # Outputting 2 values: valence and arousal
        self.valence_arousal_head = nn.Linear(hidden_size, 2)

    def forward(self, 
                input_ids=None, 
                attention_mask=None, 
                labels=None,
                output_hidden_states=False,
                **kwargs):
        
        # Forward pass through the base model
        outputs = self.base_model(
            input_ids=input_ids,
            attention_mask=attention_mask,
            labels=labels, # Labels for LM loss
            output_hidden_states=True, # We need hidden states for auxiliary heads
            **kwargs
        )

        # The last hidden state is typically used for classification heads
        # We need to select the last token's hidden state for sequence classification
        # For CausalLM, it's usually the hidden state before the LM head. 
        # If labels are provided, we should consider the token before the actual label for prediction.
        # This would be `outputs.hidden_states[-1][:, -1, :]` if we're predicting the next token.
        # However, for auxiliary heads on the *response*, we might want the average or last token of the *response*.
        # For simplicity and common practice in fine-tuning, we'll use the last token's hidden state.
        last_hidden_state = outputs.hidden_states[-1]
        
        # Get the hidden state corresponding to the last relevant token for auxiliary tasks.
        # This is often the last token in the sequence if padding is on the left, or the last non-padding token.
        # For a decoder-only model, we typically take the last token's hidden state.
        if input_ids is not None:
            # Get the hidden state of the last token (before padding, if any)
            sequence_lengths = (attention_mask != 0).sum(dim=1) - 1
            # Ensure sequence_lengths don't go out of bounds for last_hidden_state
            sequence_lengths = sequence_lengths.clamp(min=0, max=last_hidden_state.size(1) - 1)
            pooled_output = last_hidden_state[torch.arange(last_hidden_state.size(0)), sequence_lengths]
        else:
            # Fallback if input_ids is not available, might be less accurate for auxiliary tasks
            pooled_output = last_hidden_state[:, -1, :]


        # LM Loss is already computed by the base model if labels are provided
        lm_loss = outputs.loss

        # Auxiliary head predictions
        emotion_logits = self.emotion_head(pooled_output)
        strategy_logits = self.strategy_head(pooled_output)
        valence_arousal_preds = self.valence_arousal_head(pooled_output)

        return {
            "lm_loss": lm_loss,
            "emotion_logits": emotion_logits,
            "strategy_logits": strategy_logits,
            "valence_arousal_preds": valence_arousal_preds,
            "hidden_states": outputs.hidden_states if output_hidden_states else None,
            "logits": outputs.logits # Raw LM logits if needed for safety KL
        }

    def get_peft_model(self):
        """
        Returns the PEFT (QLoRA) model for fine-tuning.
        """
        return self.base_model
