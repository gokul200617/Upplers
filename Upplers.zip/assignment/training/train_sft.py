import os
import json
import argparse
from collections import defaultdict

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, Dataset
from transformers import AutoTokenizer, TrainingArguments, Trainer, DataCollatorForLanguageModeling
from accelerate import Accelerator
from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training, BitsAndBytesConfig
import numpy as np
from tqdm import tqdm
import matplotlib.pyplot as plt
import plotly.graph_objects as go

from model.modeling_vibe import VibeModel
from safety.teacher import SafetyTeacher, calculate_kl_divergence

# --- Custom Dataset for Unified Data ---
class UnifiedDataset(Dataset):
    def __init__(self, data_path, tokenizer, max_seq_length):
        self.data = []
        self.tokenizer = tokenizer
        self.max_seq_length = max_seq_length

        # Load data from JSONL
        with open(data_path, "r", encoding="utf-8") as f:
            for line in f:
                self.data.append(json.loads(line))
        
        # Map emotion and strategy labels to numerical IDs
        self.emotion_labels = sorted(list(set([d["emotion_label"] for d in self.data])))
        self.strategy_labels = sorted(list(set([d["strategy_label"] for d in self.data])))
        self.emotion_to_id = {label: i for i, label in enumerate(self.emotion_labels)}
        self.strategy_to_id = {label: i for i, label in enumerate(self.strategy_labels)}

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        item = self.data[idx]
        context = item["context"]
        assistant_target = item["assistant_target"]
        emotion_label = item["emotion_label"]
        strategy_label = item["strategy_label"]
        valence = item["valence"]
        arousal = item["arousal"]

        # Tokenize context and assistant_target
        # The model will be trained to predict `assistant_target` given `context`.
        # We combine them for causal language modeling, masking the context for LM loss.
        # However, auxiliary heads need to predict based on the final hidden state of the assistant's response.
        
        # Tokenize context
        context_tokens = self.tokenizer.encode(context, add_special_tokens=True, truncation=True, max_length=self.max_seq_length)
        # Tokenize assistant target (without special tokens, as it's a continuation)
        target_tokens = self.tokenizer.encode(assistant_target, add_special_tokens=False, truncation=True, max_length=self.max_seq_length)

        # Combine and pad
        # EOS token between context and target, then target tokens
        input_ids = context_tokens + [self.tokenizer.eos_token_id] + target_tokens
        
        # Create labels: LM loss should only be computed on the assistant_target tokens
        # -100 is the ignore_index for PyTorch CrossEntropyLoss
        labels = [-100] * (len(context_tokens) + 1) + target_tokens # +1 for EOS token
        
        # Pad to max_seq_length
        padding_length = self.max_seq_length - len(input_ids)
        if padding_length > 0:
            input_ids = input_ids + [self.tokenizer.pad_token_id] * padding_length
            labels = labels + [-100] * padding_length
        else:
            input_ids = input_ids[:self.max_seq_length]
            labels = labels[:self.max_seq_length]

        attention_mask = [1] * len(input_ids)

        # Create labels_attention_mask for auxiliary tasks and safety KL
        # This mask indicates which tokens correspond to the assistant_target.
        # It's 1 for assistant_target tokens, 0 otherwise.
        labels_attention_mask = [0] * (len(context_tokens) + 1) + [1] * len(target_tokens)
        if padding_length > 0:
            labels_attention_mask = labels_attention_mask + [0] * padding_length
        else:
            labels_attention_mask = labels_attention_mask[:self.max_seq_length]


        return {
            "input_ids": torch.tensor(input_ids, dtype=torch.long),
            "attention_mask": torch.tensor(attention_mask, dtype=torch.long),
            "labels": torch.tensor(labels, dtype=torch.long),
            "emotion_labels": torch.tensor(self.emotion_to_id[emotion_label], dtype=torch.long),
            "strategy_labels": torch.tensor(self.strategy_to_id[strategy_label], dtype=torch.long),
            "valence_arousal_labels": torch.tensor([valence, arousal], dtype=torch.float),
            "labels_attention_mask": torch.tensor(labels_attention_mask, dtype=torch.long), # For safety KL
        }

# --- Custom Data Collator ---
class CustomDataCollatorForSFT(DataCollatorForLanguageModeling):
    def __call__(self, features):
        # Extract custom labels before passing to default collator
        emotion_labels = torch.stack([f["emotion_labels"] for f in features])
        strategy_labels = torch.stack([f["strategy_labels"] for f in features])
        valence_arousal_labels = torch.stack([f["valence_arousal_labels"] for f in features])
        labels_attention_mask = torch.stack([f["labels_attention_mask"] for f in features])

        # Remove custom labels from features for the base DataCollator
        for f in features:
            del f["emotion_labels"]
            del f["strategy_labels"]
            del f["valence_arousal_labels"]
            del f["labels_attention_mask"]

        # Use the default DataCollatorForLanguageModeling for input_ids, attention_mask, labels
        batch = super().__call__(features)

        # Add custom labels back to the batch
        batch["emotion_labels"] = emotion_labels
        batch["strategy_labels"] = strategy_labels
        batch["valence_arousal_labels"] = valence_arousal_labels
        batch["labels_attention_mask"] = labels_attention_mask
        
        return batch


# --- Custom Trainer for Multi-Objective SFT ---
class MultiObjectiveSFTTrainer(Trainer):
    def __init__(self, *args, 
                 lambda_lm: float = 1.0, 
                 lambda_emotion: float = 0.2, 
                 lambda_strategy: float = 0.2, 
                 lambda_valence: float = 0.1,
                 lambda_safety: float = 0.1,
                 safety_teacher: SafetyTeacher = None,
                 **kwargs):
        super().__init__(*args, **kwargs)
        self.lambda_lm = lambda_lm
        self.lambda_emotion = lambda_emotion
        self.lambda_strategy = lambda_strategy
        self.lambda_valence = lambda_valence
        self.lambda_safety = lambda_safety
        self.safety_teacher = safety_teacher

        # Loss functions
        self.lm_loss_fct = nn.CrossEntropyLoss(ignore_index=-100)
        self.emotion_loss_fct = nn.CrossEntropyLoss()
        self.strategy_loss_fct = nn.CrossEntropyLoss()
        self.valence_arousal_loss_fct = nn.MSELoss()

    def compute_loss(self, model, inputs, return_outputs=False):
        # Forward pass through VibeModel
        outputs = model(
            input_ids=inputs["input_ids"],
            attention_mask=inputs["attention_mask"],
            labels=inputs["labels"], # For LM loss
            output_hidden_states=True # Ensure hidden states are returned
        )

        # --- Calculate individual losses ---
        # 1. LM Loss (LNLL)
        lm_loss = outputs["lm_loss"]

        # 2. Emotion Classification Loss (Lemo)
        emotion_logits = outputs["emotion_logits"]
        emotion_labels = inputs["emotion_labels"]
        emotion_loss = self.emotion_loss_fct(emotion_logits, emotion_labels)

        # 3. Strategy Classification Loss (Lstrat)
        strategy_logits = outputs["strategy_logits"]
        strategy_labels = inputs["strategy_labels"]
        strategy_loss = self.strategy_loss_fct(strategy_logits, strategy_labels)

        # 4. Valence/Arousal Regression Loss (Lval)
        valence_arousal_preds = outputs["valence_arousal_preds"]
        valence_arousal_labels = inputs["valence_arousal_labels"]
        valence_arousal_loss = self.valence_arousal_loss_fct(valence_arousal_preds, valence_arousal_labels)

        # 5. Safety KL Distillation Loss (Lsafe)
        safety_loss = torch.tensor(0.0, device=model.device) # Default to 0 if no teacher
        if self.safety_teacher:
            # Get raw LM logits from the student model for KL calculation
            student_lm_logits = outputs["logits"]
            
            # Get soft targets from the safety teacher
            with torch.no_grad(): # Teacher does not need gradients
                teacher_soft_targets = self.safety_teacher.get_safe_logits(
                    input_ids=inputs["input_ids"],
                    attention_mask=inputs["attention_mask"],
                    labels_attention_mask=inputs["labels_attention_mask"]
                )
            
            # Calculate KL divergence
            safety_loss = calculate_kl_divergence(
                student_logits=student_lm_logits,
                teacher_soft_targets=teacher_soft_targets,
                labels_attention_mask=inputs["labels_attention_mask"]
            )

        # --- Combine losses ---
        total_loss = (
            self.lambda_lm * lm_loss +
            self.lambda_emotion * emotion_loss +
            self.lambda_strategy * strategy_loss +
            self.lambda_valence * valence_arousal_loss +
            self.lambda_safety * safety_loss
        )

        return (total_loss, outputs) if return_outputs else total_loss


# --- Main Training Function ---
def train_sft(config_path: str):
    with open(config_path, 'r') as f:
        config = json.load(f)

    # Initialize Accelerator (for distributed training/mixed precision)
    accelerator = Accelerator()

    # --- Tokenizer ---
    tokenizer = AutoTokenizer.from_pretrained(config["model_name"])
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    
    # --- Datasets ---
    train_dataset = UnifiedDataset(config["train_data_path"], tokenizer, config["max_seq_length"])
    dev_dataset = UnifiedDataset(config["dev_data_path"], tokenizer, config["max_seq_length"])

    # Use the number of unique labels found in the dataset for model heads
    num_emotion_labels = len(train_dataset.emotion_labels)
    num_strategy_labels = len(train_dataset.strategy_labels)
    print(f"Detected {num_emotion_labels} emotion labels and {num_strategy_labels} strategy labels.")

    # --- Model ---
    bnb_config = None
    if config["use_4bit_quantization"]:
        bnb_config = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_quant_type=config["bnb_4bit_quant_type"],
            bnb_4bit_compute_dtype=torch.bfloat16 if config["bnb_4bit_compute_dtype"] == "bfloat16" else torch.float16,
            bnb_4bit_use_double_quant=config["bnb_4bit_use_double_quant"],
        )

    model = VibeModel(
        model_name=config["model_name"],
        num_emotion_labels=num_emotion_labels,
        num_strategy_labels=num_strategy_labels,
        quantization_config=bnb_config
    )

    # --- Safety Teacher ---
    safety_teacher = None
    if config["lambda_safety"] > 0:
        safety_teacher = SafetyTeacher(
            model_name=config["safety_teacher_model_name"],
            temperature=config["safety_teacher_temperature"],
            device=accelerator.device
        )
    
    # --- Data Collator ---
    data_collator = CustomDataCollatorForSFT(tokenizer=tokenizer, mlm=False)

    # --- Training Arguments ---
    training_args = TrainingArguments(
        output_dir=config["output_dir"],
        logging_dir=config["logging_dir"],
        per_device_train_batch_size=config["per_device_train_batch_size"],
        per_device_eval_batch_size=config["per_device_eval_batch_size"],
        gradient_accumulation_steps=config["gradient_accumulation_steps"],
        learning_rate=config["learning_rate"],
        num_train_epochs=config["num_train_epochs"],
        weight_decay=config["weight_decay"],
        lr_scheduler_type=config["lr_scheduler_type"],
        warmup_ratio=config["warmup_ratio"],
        save_strategy="epoch",
        logging_strategy="epoch",
        evaluation_strategy="epoch",
        fp16=accelerator.use_fp16, # Use mixed precision if available via accelerator
        bf16=accelerator.use_bf16, # Use bfloat16 if available via accelerator
        report_to="tensorboard", # Or "wandb", etc.
        gradient_checkpointing=config["gradient_checkpointing"],
        remove_unused_columns=False, # Keep custom labels
    )

    # --- Trainer ---
    trainer = MultiObjectiveSFTTrainer(
        model=model,
        args=training_args,
        train_dataset=train_dataset,
        eval_dataset=dev_dataset,
        tokenizer=tokenizer,
        data_collator=data_collator,
        lambda_lm=config["lambda_lm"],
        lambda_emotion=config["lambda_emotion"],
        lambda_strategy=config["lambda_strategy"],
        lambda_valence=config["lambda_valence"],
        lambda_safety=config["lambda_safety"],
        safety_teacher=safety_teacher,
    )

    # --- Train ---
    print("Starting training...")
    trainer.train()
    print("Training complete.")

    # --- Save final model ---
    final_model_path = os.path.join(config["output_dir"], "final_model")
    trainer.save_model(final_model_path)
    tokenizer.save_pretrained(final_model_path)
    print(f"Final model saved to {final_model_path}")

    # --- Plotting Loss Curves (Example with Matplotlib, for actual use Plotly) ---
    # This is a placeholder. In a real scenario, you'd use the trainer.state.log_history
    # or integrate with a logging framework like TensorBoard/WandB to plot.
    
    # For demonstration, we'll create dummy plots or use a simplified approach.
    # Ideally, plots would be generated from the actual training logs.
    print("Generating loss curves...")
    logs = trainer.state.log_history
    
    # Filter for relevant metrics
    train_losses = [entry["loss"] for entry in logs if "loss" in entry]
    eval_losses = [entry["eval_loss"] for entry in logs if "eval_loss" in entry]
    steps = [entry["step"] for entry in logs if "loss" in entry]

    if train_losses and eval_losses:
        plt.figure(figsize=(10, 6))
        plt.plot(steps[:len(train_losses)], train_losses, label="Training Loss")
        plt.plot(steps[:len(eval_losses)], eval_losses, label="Validation Loss")
        plt.xlabel("Steps")
        plt.ylabel("Loss")
        plt.title("Training and Validation Loss Curves")
        plt.legend()
        plt.grid(True)
        plt.savefig(os.path.join(config["logging_dir"], "loss_curves_matplotlib.png"))
        print(f"Loss curves saved to {os.CWD}{os.path.join(config["logging_dir"], "loss_curves_matplotlib.png")}")

    # Plotly example (more interactive, but harder to save directly without a full setup)
    if train_losses and eval_losses:
        fig = go.Figure()
        fig.add_trace(go.Scatter(x=steps[:len(train_losses)], y=train_losses, mode='lines+markers', name='Training Loss'))
        fig.add_trace(go.Scatter(x=steps[:len(eval_losses)], y=eval_losses, mode='lines+markers', name='Validation Loss'))
        fig.update_layout(title='Training and Validation Loss Curves', xaxis_title='Steps', yaxis_title='Loss')
        fig.write_html(os.path.join(config["logging_dir"], "loss_curves_plotly.html"))
        print(f"Interactive loss curves saved to {os.CWD}{os.path.join(config["logging_dir"], "loss_curves_plotly.html")}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Multi-Objective SFT Training for Vibe AI Chatbot.")
    parser.add_argument("--config_path", type=str, default="config/sft_config.json",
                        help="Path to the SFT training configuration JSON file.")
    args = parser.parse_args()

    train_sft(args.config_path)
