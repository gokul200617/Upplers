import os
import json
import argparse
from typing import Dict, Union, List, Optional

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, Dataset
from transformers import AutoTokenizer, TrainingArguments, Trainer, AutoModelForCausalLM
from accelerate import Accelerator
from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training, BitsAndBytesConfig
import numpy as np
from tqdm import tqdm
import matplotlib.pyplot as plt
import plotly.graph_objects as go

from model.modeling_vibe import VibeModel

# --- Custom Dataset for DPO ---
class PreferenceDataset(Dataset):
    def __init__(self, data_path, tokenizer, max_seq_length):
        self.data = []
        self.tokenizer = tokenizer
        self.max_seq_length = max_seq_length

        with open(data_path, "r", encoding="utf-8") as f:
            for line in f:
                self.data.append(json.loads(line))

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        item = self.data[idx]
        context = item["context"]
        chosen = item["chosen"]
        rejected = item["rejected"]

        # Tokenize chosen response
        chosen_tokens = self.tokenizer.encode(
            context + self.tokenizer.eos_token + chosen,
            add_special_tokens=True,
            truncation=True,
            max_length=self.max_seq_length,
            return_tensors="pt"
        )

        # Tokenize rejected response
        rejected_tokens = self.tokenizer.encode(
            context + self.tokenizer.eos_token + rejected,
            add_special_tokens=True,
            truncation=True,
            max_length=self.max_seq_length,
            return_tensors="pt"
        )

        return {
            "input_ids_chosen": chosen_tokens.squeeze(0),
            "attention_mask_chosen": (chosen_tokens.squeeze(0) != self.tokenizer.pad_token_id).long(),
            "input_ids_rejected": rejected_tokens.squeeze(0),
            "attention_mask_rejected": (rejected_tokens.squeeze(0) != self.tokenizer.pad_token_id).long(),
        }

# --- Custom Data Collator for DPO ---
class DataCollatorForDPO:
    def __init__(self, tokenizer, max_seq_length):
        self.tokenizer = tokenizer
        self.max_seq_length = max_seq_length

    def __call__(self, features):
        batch = {}

        # Pad chosen sequences
        input_ids_chosen = [f["input_ids_chosen"] for f in features]
        attention_mask_chosen = [f["attention_mask_chosen"] for f in features]
        
        padded_input_ids_chosen = torch.nn.utils.rnn.pad_sequence(
            input_ids_chosen, batch_first=True, padding_value=self.tokenizer.pad_token_id
        )[:, :self.max_seq_length]
        padded_attention_mask_chosen = torch.nn.utils.rnn.pad_sequence(
            attention_mask_chosen, batch_first=True, padding_value=0
        )[:, :self.max_seq_length]

        # Pad rejected sequences
        input_ids_rejected = [f["input_ids_rejected"] for f in features]
        attention_mask_rejected = [f["attention_mask_rejected"] for f in features]

        padded_input_ids_rejected = torch.nn.utils.rnn.pad_sequence(
            input_ids_rejected, batch_first=True, padding_value=self.tokenizer.pad_token_id
        )[:, :self.max_seq_length]
        padded_attention_mask_rejected = torch.nn.utils.rnn.pad_sequence(
            attention_mask_rejected, batch_first=True, padding_value=0
        )[:, :self.max_seq_length]

        batch["input_ids_chosen"] = padded_input_ids_chosen
        batch["attention_mask_chosen"] = padded_attention_mask_chosen
        batch["input_ids_rejected"] = padded_input_ids_rejected
        batch["attention_mask_rejected"] = padded_attention_mask_rejected

        return batch

# --- DPO Loss Calculation ---
def dpo_loss_fn(
    policy_chosen_logps: torch.Tensor,
    policy_rejected_logps: torch.Tensor,
    reference_chosen_logps: torch.Tensor,
    reference_rejected_logps: torch.Tensor,
    beta: float,
    lambda_violation: float = 0.0, # Safety violation penalty
) -> Dict[str, torch.Tensor]:
    """
    Calculates the Direct Preference Optimization (DPO) loss.

    LDPO = −log σ( β( logπθ(y+) − logπθ(y−) - (logπref(y+) − logπref(y−)) ))
    
    Args:
        policy_chosen_logps (torch.Tensor): Log probabilities of chosen responses under the policy model.
        policy_rejected_logps (torch.Tensor): Log probabilities of rejected responses under the policy model.
        reference_chosen_logps (torch.Tensor): Log probabilities of chosen responses under the reference model.
        reference_rejected_logps (torch.Tensor): Log probabilities of rejected responses under the reference model.
        beta (float): Temperature parameter for the DPO loss.
        lambda_violation (float): Weight for the safety violation penalty.

    Returns:
        Dict[str, torch.Tensor]: A dictionary containing the total loss and its components.
    """

    pi_logratios = policy_chosen_logps - policy_rejected_logps
    ref_logratios = reference_chosen_logps - reference_rejected_logps

    # The core DPO loss
    logits = beta * (pi_logratios - ref_logratios)
    losses = -F.logsigmoid(logits)

    # Safety Violation Penalty (conceptual: a more robust implementation would involve safety classifier scores)
    # For demonstration, let's assume 'rejected' responses are more likely to be 'unsafe'
    # and we penalize the policy for assigning high probability to them.
    safety_violation_penalty = torch.tensor(0.0, device=logits.device)
    if lambda_violation > 0.0:
        # A simple heuristic: if policy_rejected_logps is high, it means the model is likely to generate rejected.
        # This is a highly simplified proxy. A true safety penalty would come from a separate safety classifier.
        safety_violation_penalty = lambda_violation * torch.mean(torch.exp(policy_rejected_logps))
    
    total_loss = losses.mean() + safety_violation_penalty

    return {
        "loss": total_loss,
        "losses": losses,
        "pi_logratios": pi_logratios,
        "ref_logratios": ref_logratios,
        "logits": logits,
        "safety_violation_penalty": safety_violation_penalty,
    }


# --- Custom DPOTrainer ---
class DPOTrainer(Trainer):
    def __init__(self, *args, 
                 beta: float,
                 lambda_violation: float = 0.0,
                 ref_model: Optional[VibeModel] = None,
                 **kwargs):
        super().__init__(*args, **kwargs)
        self.beta = beta
        self.lambda_violation = lambda_violation
        self.ref_model = ref_model # Reference model (usually the SFT model)
        if self.ref_model:
            self.ref_model.eval()

    def _get_log_probs(self, model: nn.Module, input_ids: torch.Tensor, attention_mask: torch.Tensor) -> torch.Tensor:
        """
        Calculates the log probabilities of the sequence for DPO.
        Only considers the tokens after the context for probability calculation.
        """
        outputs = model(
            input_ids=input_ids,
            attention_mask=attention_mask,
            labels=input_ids, # Pass input_ids as labels to get LM loss for the whole sequence
        )
        logits = outputs["logits"]

        # Shift logits and labels for causal LM
        shift_logits = logits[..., :-1, :].contiguous()
        shift_labels = input_ids[..., 1:].contiguous()
        shift_attention_mask = attention_mask[..., 1:].contiguous()

        # Compute log probabilities
        log_probs = F.log_softmax(shift_logits, dim=-1)
        
        # Select log probabilities corresponding to the actual labels
        # Use gather for efficient indexing
        selected_log_probs = torch.gather(log_probs, dim=-1, index=shift_labels.unsqueeze(-1)).squeeze(-1)

        # Mask out padding tokens
        masked_log_probs = selected_log_probs * shift_attention_mask

        # Sum log probabilities for the entire sequence (excluding context part for DPO)
        # For DPO, we want log p(y|x) - log p(y_ref|x) where y is the response, x is the context.
        # The `input_ids` here already contain `context + eos + response`.
        # We need to compute the loss only for the `response` part.
        # A more robust way would be to identify the response start index dynamically.
        # For now, let's assume log_probs are for the entire sequence and we need to adapt.

        # In DPO, it's typically log P(response | context) - we are effectively training on the full sequence here.
        # The original DPO paper formulation implies this, where r(x,y) = log P_theta(y|x)
        # So we sum over all tokens in the response.
        return masked_log_probs.sum(dim=-1) # Sum over sequence length

    def compute_loss(self, model, inputs, return_outputs=False):
        # Extract chosen and rejected inputs
        input_ids_chosen = inputs["input_ids_chosen"]
        attention_mask_chosen = inputs["attention_mask_chosen"]
        input_ids_rejected = inputs["input_ids_rejected"]
        attention_mask_rejected = inputs["attention_mask_rejected"]

        # Calculate log probabilities for chosen and rejected responses under the policy model
        policy_chosen_logps = self._get_log_probs(model, input_ids_chosen, attention_mask_chosen)
        policy_rejected_logps = self._get_log_probs(model, input_ids_rejected, attention_mask_rejected)

        # Calculate log probabilities under the reference model (no gradients for ref_model)
        with torch.no_grad():
            reference_chosen_logps = self._get_log_probs(self.ref_model, input_ids_chosen, attention_mask_chosen)
            reference_rejected_logps = self._get_log_probs(self.ref_model, input_ids_rejected, attention_mask_rejected)

        # Compute DPO loss
        loss_dict = dpo_loss_fn(
            policy_chosen_logps=policy_chosen_logps,
            policy_rejected_logps=policy_rejected_logps,
            reference_chosen_logps=reference_chosen_logps,
            reference_rejected_logps=reference_rejected_logps,
            beta=self.beta,
            lambda_violation=self.lambda_violation,
        )
        total_loss = loss_dict["loss"]

        return (total_loss, loss_dict) if return_outputs else total_loss


# --- Main DPO Training Function ---
def train_dpo(config_path: str):
    with open(config_path, 'r') as f:
        config = json.load(f)

    accelerator = Accelerator()

    # --- Tokenizer ---
    tokenizer = AutoTokenizer.from_pretrained(config["model_name"])
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    
    # --- Datasets ---
    train_dataset = PreferenceDataset(config["preference_data_path"], tokenizer, config["max_seq_length"])
    # For DPO, typically we don't need a separate dev set as much as SFT, but it's good practice.
    # For simplicity, we'll just use a small subset of train_dataset as 'eval_dataset' if needed,
    # or skip explicit evaluation during DPO if the preference data is small.
    # Let's create a dummy eval dataset for compatibility with Trainer.
    eval_size = max(1, len(train_dataset) // 10) # 10% for eval
    train_data, eval_data = torch.utils.data.random_split(train_dataset, [len(train_dataset) - eval_size, eval_size])

    # --- Policy Model (VibeModel) ---
    bnb_config = None
    if config["use_4bit_quantization"]:
        bnb_config = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_quant_type=config["bnb_4bit_quant_type"],
            bnb_4bit_compute_dtype=torch.bfloat16 if config["bnb_4bit_compute_dtype"] == "bfloat16" else torch.float16,
            bnb_4bit_use_double_quant=config["bnb_4bit_use_double_quant"],
        )

    # Load the policy model from the SFT checkpoint
    print(f"Loading policy model from SFT checkpoint: {config["sft_model_path"]}")
    # VibeModel requires num_emotion_labels, num_strategy_labels during initialization.
    # These should be saved with the SFT model or derived from the dataset.
    # For now, let's use dummy values or assume they are in the config.
    # A more robust solution would load these from the SFT model's config or from the dataset's data cards.
    # For this example, we'll load a simple AutoModelForCausalLM as the policy model
    # as VibeModel includes auxiliary heads not strictly needed for DPO's LM probability calculation.
    # However, to be consistent, we can still use VibeModel and just ignore auxiliary head outputs.
    # We need to know the correct num_emotion_labels and num_strategy_labels. This implies saving them
    # during SFT training or re-calculating from the unified dataset.
    # For now, let's load a standard CausalLM and then convert it to PEFT.

    # Placeholder: Assuming you have the exact `num_emotion_labels` and `num_strategy_labels` from SFT stage.
    # In a real scenario, you'd save these or re-derive from data.
    # For this example, let's use arbitrary values or load from a dummy config.
    # A better approach is to load the full VibeModel checkpoint including auxiliary heads.
    # But for DPO, we only care about the LM head's log_probs.

    # Let's load the `AutoModelForCausalLM` directly and apply LoRA.
    policy_model = AutoModelForCausalLM.from_pretrained(
        config["model_name"],
        quantization_config=bnb_config if config["use_4bit_quantization"] else None,
        torch_dtype=torch.bfloat16 if config["use_4bit_quantization"] else torch.float32
    )
    if config["use_4bit_quantization"]:
        policy_model = prepare_model_for_kbit_training(policy_model)
    lora_config = LoraConfig(
        r=8, lora_alpha=16, target_modules=["q_proj", "v_proj"],
        lora_dropout=0.05, bias="none", task_type="CAUSAL_LM"
    )
    policy_model = get_peft_model(policy_model, lora_config)
    policy_model.print_trainable_parameters()
    
    # Load SFT trained weights into policy_model (this will load LoRA weights)
    # This assumes the SFT model was saved with PEFT format.
    try:
        policy_model.load_adapter(config["sft_model_path"], adapter_name="sft_adapter")
        policy_model.set_adapter("sft_adapter")
        print(f"Successfully loaded SFT adapter from {config["sft_model_path"]}")
    except Exception as e:
        print(f"Could not load SFT adapter: {e}. Training from base model weights.")


    # --- Reference Model ---
    # The reference model should be the SFT model without further training.
    # It should not have gradients updated during DPO.
    ref_model = AutoModelForCausalLM.from_pretrained(
        config["model_name"],
        quantization_config=bnb_config if config["use_4bit_quantization"] else None,
        torch_dtype=torch.bfloat16 if config["use_4bit_quantization"] else torch.float32
    )
    if config["use_4bit_quantization"]:
        ref_model = prepare_model_for_kbit_training(ref_model)
    ref_model = get_peft_model(ref_model, lora_config)
    ref_model.eval() # Reference model should be in evaluation mode
    
    try:
        ref_model.load_adapter(config["sft_model_path"], adapter_name="sft_adapter")
        ref_model.set_adapter("sft_adapter")
        print(f"Successfully loaded SFT adapter into reference model from {config["sft_model_path"]}")
    except Exception as e:
        print(f"Could not load SFT adapter for reference model: {e}. Using base model as reference.")


    # --- Data Collator ---
    data_collator = DataCollatorForDPO(tokenizer=tokenizer, max_seq_length=config["max_seq_length"])

    # --- Training Arguments ---
    training_args = TrainingArguments(
        output_dir=config["output_dir"],
        logging_dir=config["logging_dir"],
        per_device_train_batch_size=config["per_device_train_batch_size"],
        per_device_eval_batch_size=config["per_device_eval_batch_size"],
        gradient_accumulation_steps=config["gradient_accumulation_steps"],
        learning_rate=config["learning_rate"],
        num_train_epochs=config["num_train_epochs"],
        weight_decay=config["weight_decay"],
        lr_scheduler_type=config["lr_scheduler_type"],
        warmup_ratio=config["warmup_ratio"],
        save_strategy="epoch",
        logging_strategy="epoch",
        evaluation_strategy="epoch",
        fp16=accelerator.use_fp16,
        bf16=accelerator.use_bf16,
        report_to="tensorboard",
        gradient_checkpointing=config["gradient_checkpointing"],
        remove_unused_columns=False,
    )

    # --- Trainer ---
    trainer = DPOTrainer(
        model=policy_model,
        args=training_args,
        train_dataset=train_data,
        eval_dataset=eval_data,
        tokenizer=tokenizer,
        data_collator=data_collator,
        beta=config["beta"],
        lambda_violation=config["lambda_violation"],
        ref_model=ref_model,
    )

    # --- Train ---
    print("Starting DPO training...")
    trainer.train()
    print("DPO training complete.")

    # --- Save final model ---
    final_model_path = os.path.join(config["output_dir"], "final_dpo_model")
    trainer.save_model(final_model_path)
    tokenizer.save_pretrained(final_model_path)
    print(f"Final DPO model saved to {final_model_path}")

    # --- Plotting Loss Curves ---
    print("Generating DPO loss curves...")
    logs = trainer.state.log_history
    
    train_losses = [entry["loss"] for entry in logs if "loss" in entry]
    eval_losses = [entry["eval_loss"] for entry in logs if "eval_loss" in entry]
    steps = [entry["step"] for entry in logs if "loss" in entry]

    if train_losses:
        plt.figure(figsize=(10, 6))
        plt.plot(steps[:len(train_losses)], train_losses, label="DPO Training Loss")
        if eval_losses: # Plot eval loss only if available
            plt.plot(steps[:len(eval_losses)], eval_losses, label="DPO Validation Loss")
        plt.xlabel("Steps")
        plt.ylabel("Loss")
        plt.title("DPO Training and Validation Loss Curves")
        plt.legend()
        plt.grid(True)
        plt.savefig(os.path.join(config["logging_dir"], "dpo_loss_curves_matplotlib.png"))
        print(f"DPO Loss curves saved to {os.CWD}{os.path.join(config["logging_dir"], "dpo_loss_curves_matplotlib.png")}")

    if train_losses:
        fig = go.Figure()
        fig.add_trace(go.Scatter(x=steps[:len(train_losses)], y=train_losses, mode='lines+markers', name='DPO Training Loss'))
        if eval_losses:
            fig.add_trace(go.Scatter(x=steps[:len(eval_losses)], y=eval_losses, mode='lines+markers', name='DPO Validation Loss'))
        fig.update_layout(title='DPO Training and Validation Loss Curves', xaxis_title='Steps', yaxis_title='Loss')
        fig.write_html(os.path.join(config["logging_dir"], "dpo_loss_curves_plotly.html"))
        print(f"Interactive DPO loss curves saved to {os.CWD}{os.path.join(config["logging_dir"], "dpo_loss_curves_plotly.html")}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Direct Preference Optimization (DPO) Training for Vibe AI Chatbot.")
    parser.add_argument("--config_path", type=str, default="config/dpo_config.json",
                        help="Path to the DPO training configuration JSON file.")
    args = parser.parse_args()

    train_dpo(args.config_path)
