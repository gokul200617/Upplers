import torch
import json
import argparse
from transformers import AutoTokenizer, AutoModelForCausalLM
from peft import PeftModel

class VibeInferenceController:
    """
    Manages the inference process for the Vibe AI Chatbot, including 2-step decoding
    (internal reflection followed by final response) and a safety fallback mechanism.
    """
    def __init__(self, model_path: str, tokenizer_path: str, config_path: str):
        print(f"Loading inference configuration from {config_path}...")
        with open(config_path, 'r') as f:
            self.config = json.load(f)

        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        print(f"Using device: {self.device}")

        print(f"Loading tokenizer from {tokenizer_path}...")
        self.tokenizer = AutoTokenizer.from_pretrained(tokenizer_path)
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token

        print(f"Loading base model from {self.config["model_path"]}...")
        # For inference, we can directly load the PEFT model if it was saved correctly.
        # If the model_path points to a directory containing adapters, it will load them.
        # If it's a full model checkpoint, it will load the full model.

        # First load the base model without any adapters
        base_model = AutoModelForCausalLM.from_pretrained(
            self.config["model_path"],
            torch_dtype=torch.bfloat16 if torch.cuda.is_available() else torch.float32
        ).to(self.device)

        # If the model_path is a PEFT adapter, then load it. Otherwise, assume it's a full model.
        try:
            # Try to load as a PEFT model if adapter_config.json exists
            if os.path.exists(os.path.join(model_path, "adapter_config.json")):
                self.model = PeftModel.from_pretrained(base_model, model_path).to(self.device)
                print("Loaded model as PEFT adapter.")
            else:
                self.model = base_model # Assume it's a full model if no adapter config
                print("Loaded full model.")
        except Exception as e:
            print(f"Error loading PEFT model: {e}. Attempting to load as a full model.")
            self.model = base_model

        self.model.eval()

    def _reflect_internally(self, user_input: str) -> str:
        """
        Generates an internal reflection (not shown to the user) based on the user's input.
        This step aims to identify emotions, acknowledge, and formulate a gentle follow-up.
        """
        reflection_prompt = (
            f"User input: '{user_input}'\n\n"
            "Internal Reflection (Acknowledge, Emotion Naming, Gentle Follow-up Question):\n"
            "- Acknowledgment: "
        )
        
        inputs = self.tokenizer(reflection_prompt, return_tensors="pt").to(self.device)
        
        # Generate a short reflection
        reflection_output = self.model.generate(
            **inputs,
            max_new_tokens=64, # Limit reflection length
            do_sample=True,
            temperature=0.8,
            top_k=50,
            top_p=0.9,
            pad_token_id=self.tokenizer.pad_token_id
        )
        reflection_text = self.tokenizer.decode(reflection_output[0], skip_special_tokens=True)
        
        # Post-process to extract only the reflection part
        # This is a heuristic and might need fine-tuning based on actual model output
        start_idx = reflection_text.find("Internal Reflection")
        if start_idx != -1:
            reflection_text = reflection_text[start_idx:]
        return reflection_text

    def _is_directive_or_advice(self, text: str) -> bool:
        """
        Heuristic to detect if the generated text contains directive language or advice.
        This would ideally be replaced by a more robust safety classifier.
        """
        directive_keywords = ["you should", "you must", "I advise you", "my recommendation is"]
        advice_keywords = ["try to", "consider", "it's best to"]
        
        text_lower = text.lower()
        for keyword in directive_keywords + advice_keywords:
            if keyword in text_lower:
                return True
        return False

    def _generate_response(self, prompt: str, penalize_safety: bool = False) -> str:
        """
        Generates the final chatbot response.
        """
        inputs = self.tokenizer(prompt, return_tensors="pt").to(self.device)
        
        # Apply safety penalty if needed
        if penalize_safety:
            # This is a conceptual implementation. Real safety penalties would involve
            # modifying logits based on a safety classifier's output.
            # For simple demonstration, we can try to lower the temperature or top_p
            # to make the output more generic, or explicitly add negative prompts.
            # Here, we'll use a higher repetition penalty and lower temperature/top_p
            # as a proxy for 're-decode with penalties'.
            temperature = max(0.1, self.config["temperature"] * 0.7) # Make it less creative
            top_p = min(0.99, self.config["top_p"] * 0.8) # Reduce diversity
            repetition_penalty = self.config["repetition_penalty"] * self.config["safety_penalty_factor"]
            print("Applying safety penalties for re-decoding.")
        else:
            temperature = self.config["temperature"]
            top_p = self.config["top_p"]
            repetition_penalty = self.config["repetition_penalty"]

        generation_output = self.model.generate(
            **inputs,
            max_new_tokens=self.config["max_new_tokens"],
            do_sample=True,
            temperature=temperature,
            top_k=self.config["top_k"],
            top_p=top_p,
            repetition_penalty=repetition_penalty,
            pad_token_id=self.tokenizer.pad_token_id,
            eos_token_id=self.tokenizer.eos_token_id,
        )
        response_text = self.tokenizer.decode(generation_output[0][inputs["input_ids"].shape[1]:], skip_special_tokens=True)
        return response_text

    def generate_empathetic_response(self, user_input: str) -> str:
        """
        Generates an empathetic response to user input using 2-step decoding and safety fallback.
        """
        if self.config["two_step_decoding"]:
            # Step 1: Internal Reflection
            print("Performing internal reflection...")
            reflection = self._reflect_internally(user_input)
            print(f"Internal Reflection: {reflection}")
            
            # Construct the prompt for the final response, incorporating reflection (optional, for subtle guidance)
            # For simplicity, we'll just use the user_input + style tokens for the final prompt
            # but a real implementation might use information extracted from reflection.
            final_response_prompt = (
                f"User: {user_input}\n"
                f"Assistant (Internal thought: {reflection}) {self.config["style_tokens"]}"
            )

        else:
            final_response_prompt = f"User: {user_input}\nAssistant: {self.config["style_tokens"]}"

        # Step 2: Generate Final Response
        response = self._generate_response(final_response_prompt, penalize_safety=False)
        print(f"Initial response generated: {response}")

        # Safety Fallback
        if self.config["safety_fallback_enabled"] and self._is_directive_or_advice(response):
            print("Safety fallback triggered: Directive/advice pattern detected. Re-decoding...")
            fallback_response = self._generate_response(final_response_prompt, penalize_safety=True)
            return fallback_response
        
        return response


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Generate empathetic responses with Vibe AI Chatbot.")
    parser.add_argument("--config_path", type=str, default="config/inference_config.json",
                        help="Path to the inference configuration JSON file.")
    parser.add_argument("--model_path", type=str, default="dpo_checkpoints/final_dpo_model",
                        help="Path to the trained model (SFT or DPO checkpoint).")
    parser.add_argument("--tokenizer_path", type=str, default="dpo_checkpoints/final_dpo_model",
                        help="Path to the tokenizer.")
    args = parser.parse_args()

    # Ensure model_path and tokenizer_path from args override config if provided
    # This allows more flexibility in specifying which model to load at runtime
    inference_config_override = {
        "model_path": args.model_path,
        "tokenizer_path": args.tokenizer_path
    }
    
    # Load the main config and then override with command line args
    with open(args.config_path, 'r') as f:
        base_config = json.load(f)
    base_config.update(inference_config_override) # Merge command line overrides

    # Save this combined config temporarily to a new path to ensure InferenceController loads it
    # Or, pass the combined config directly if the InferenceController was designed to accept a dict.
    # For now, let's write a temp config file.
    temp_config_path = "temp_inference_config.json"
    with open(temp_config_path, 'w') as f:
        json.dump(base_config, f, indent=4)

    controller = VibeInferenceController(
        model_path=base_config["model_path"], 
        tokenizer_path=base_config["tokenizer_path"], 
        config_path=temp_config_path
    )

    print("\n--- Vibe AI Chatbot Inference ---\n")
    while True:
        user_input = input("You: ")
        if user_input.lower() in ["exit", "quit"]:
            break
        response = controller.generate_empathetic_response(user_input)
        print(f"Vibe AI: {response}")
    
    # Clean up temporary config file
    os.remove(temp_config_path)
