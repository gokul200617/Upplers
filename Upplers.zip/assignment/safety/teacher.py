import torch
import torch.nn.functional as F
from transformers import AutoTokenizer, AutoModelForCausalLM

class SafetyTeacher:
    """
    A safety teacher model that provides 'safe' logits for KL divergence distillation.
    It uses a rules-prompted approach to guide a base language model towards safe responses.
    """
    def __init__(self, 
                 model_name: str = "distilbert/distilgpt2", 
                 temperature: float = 2.0,
                 device: str = "cuda" if torch.cuda.is_available() else "cpu"):
        
        self.device = device
        self.temperature = temperature
        print(f"Loading Safety Teacher model {model_name}...")
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        self.model = AutoModelForCausalLM.from_pretrained(model_name).to(self.device)
        self.model.eval() # Set to evaluation mode

        # Add a pad token if it doesn't exist, as some models don't have it by default
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token
            self.model.config.pad_token_id = self.model.config.eos_token_id

        # Example safety rules prompt (can be extended or loaded from a file)
        self.safety_prefix = (
            "The following is a safety instruction: Respond in a helpful, harmless, and unbiased manner. "
            "Avoid providing advice, hateful content, or promoting illegal activities. "
            "Always prioritize user safety and ethical guidelines. "
            "Based on this, generate a safe and appropriate response to the user input: "
        )

    @torch.no_grad()
    def get_safe_logits(self, input_ids: torch.Tensor, attention_mask: torch.Tensor, labels_attention_mask: torch.Tensor):
        """
        Generates soft targets (logits) from the safety teacher model for a given input.
        The safety prefix is prepended to the input context to guide the teacher's response.

        Args:
            input_ids (torch.Tensor): Input token IDs from the student model's tokenizer.
            attention_mask (torch.Tensor): Attention mask from the student model's tokenizer.
            labels_attention_mask (torch.Tensor): Mask indicating which tokens correspond to the assistant's response (labels).

        Returns:
            torch.Tensor: Soft targets (logits) from the safety teacher, with temperature applied.
        """
        # Prepare the input for the safety teacher by prepending the safety prefix
        # This requires re-tokenizing the input with the safety prefix combined with the context
        # For simplicity in this example, we assume `input_ids` here already contains the context
        # and we need to produce logits for the `assistant_target` part.
        # A more robust implementation might involve re-tokenizing the full prompt (prefix + context).

        # For now, let's assume the input_ids represent the full sequence (context + assistant_target)
        # and we are interested in the logits for the `assistant_target` portion.

        # The prompt for the teacher should include the safety prefix + the user's context.
        # This is a simplified approach. In a real scenario, you'd likely construct the teacher's
        # input based on the *user's original input* and *not* the combined student input_ids.
        # However, for calculating KL between student and teacher *on the assistant_target*, we need
        # to ensure the teacher's logits align with the student's prediction tokens.

        # For distillation, we need the teacher to provide logits for the *assistant_target* tokens.
        # The student model's `input_ids` will contain `[context_tokens, assistant_target_tokens]`.
        # We need the teacher to generate logits for `assistant_target_tokens` given `context_tokens` (with safety prefix).

        # For simplicity, let's just run the full `input_ids` through the teacher and then select the relevant logits.
        # A more advanced approach would involve feeding only the context to the teacher, generating tokens,
        # and then aligning them. But for KL distillation on fixed labels, this is okay if we mask correctly.

        teacher_outputs = self.model(
            input_ids=input_ids,
            attention_mask=attention_mask,
            output_hidden_states=False
        )
        teacher_logits = teacher_outputs.logits

        # Apply temperature to soften the teacher's probability distribution
        soft_targets = teacher_logits / self.temperature

        # We only care about the logits corresponding to the assistant's response (labels_attention_mask)
        # The labels_attention_mask should be 1 for assistant_target tokens and 0 otherwise.
        # Expand labels_attention_mask to match logits dimensions (batch_size, sequence_length, vocab_size)
        expanded_labels_mask = labels_attention_mask.unsqueeze(-1).expand_as(soft_targets)

        # Mask out logits for non-label tokens
        # Set logits to a very small negative number so they don't contribute to KL if not part of the labels
        masked_soft_targets = soft_targets.masked_fill(expanded_labels_mask == 0, -1e9)

        return masked_soft_targets

def calculate_kl_divergence(student_logits: torch.Tensor, teacher_soft_targets: torch.Tensor, labels_attention_mask: torch.Tensor):
    """
    Calculates the KL divergence between student model logits and teacher soft targets.
    Only computes KL for the tokens specified by the labels_attention_mask.

    Args:
        student_logits (torch.Tensor): Logits from the student model (batch_size, sequence_length, vocab_size).
        teacher_soft_targets (torch.Tensor): Soft targets (logits) from the teacher model (batch_size, sequence_length, vocab_size).
        labels_attention_mask (torch.Tensor): Mask indicating which tokens correspond to the assistant's response (labels).

    Returns:
        torch.Tensor: Scalar tensor representing the mean KL divergence loss.
    """
    # Ensure student logits and teacher soft targets are on the same device
    teacher_soft_targets = teacher_soft_targets.to(student_logits.device)

    # Apply softmax to get probability distributions
    student_probs = F.log_softmax(student_logits, dim=-1) # Log probabilities for KL_div
    teacher_probs = F.softmax(teacher_soft_targets, dim=-1)

    # Calculate KL divergence element-wise: D_KL(P || Q) = sum(P * log(P / Q))
    # torch.nn.functional.kl_div expects log_prob for input and prob for target
    # Reduction 'none' means we get divergence for each element (batch, seq_len, vocab_size)
    kl_loss = F.kl_div(student_probs, teacher_probs, reduction='none', log_target=False)

    # Only consider tokens that are part of the assistant's response (labels)
    # Sum across the vocabulary dimension for each token
    kl_loss = kl_loss.sum(dim=-1)

    # Apply the labels_attention_mask to only consider relevant tokens
    # kl_loss will be (batch_size, sequence_length)
    masked_kl_loss = kl_loss * labels_attention_mask

    # Average over the non-zero elements (tokens that are part of the labels)
    # Avoid division by zero if there are no labels in a batch
    num_labels_tokens = labels_attention_mask.sum()
    if num_labels_tokens > 0:
        return masked_kl_loss.sum() / num_labels_tokens
    else:
        return torch.tensor(0.0, device=student_logits.device)

if __name__ == "__main__":
    # Example usage
    print("Initializing SafetyTeacher...")
    safety_teacher = SafetyTeacher()

    tokenizer = safety_teacher.tokenizer
    model = safety_teacher.model

    # Example input
    context = "I am feeling very sad and alone."
    assistant_response = "I'm sorry to hear that you're feeling this way. I'm here for you."

    full_text = context + tokenizer.eos_token + assistant_response # Simulate combined input

    # Tokenize the full text
    inputs = tokenizer(full_text, return_tensors="pt", padding=True, truncation=True)
    input_ids = inputs["input_ids"]
    attention_mask = inputs["attention_mask"]

    # Create a dummy labels_attention_mask for the assistant_response part
    # This is a simplified way to get the mask for the assistant_response
    # In actual training, this mask would be generated during data preparation
    context_len = len(tokenizer.encode(context, add_special_tokens=True))
    assistant_response_len = len(tokenizer.encode(assistant_response, add_special_tokens=False))

    labels_attention_mask = torch.zeros_like(input_ids)
    # Mark the assistant response tokens as 1 for the mask
    if input_ids.shape[1] > context_len:
        labels_attention_mask[:, context_len:context_len + assistant_response_len] = 1

    print("Generating safe logits from teacher...")
    teacher_soft_targets = safety_teacher.get_safe_logits(
        input_ids=input_ids,
        attention_mask=attention_mask,
        labels_attention_mask=labels_attention_mask
    )
    print(f"Teacher soft targets shape: {teacher_soft_targets.shape}")

    # Simulate student model logits
    vocab_size = model.config.vocab_size
    student_logits = torch.randn(input_ids.shape[0], input_ids.shape[1], vocab_size).to(safety_teacher.device)
    student_logits.requires_grad = True # Student logits are usually from a model and require gradients

    print("Calculating KL divergence...")
    kl_loss = calculate_kl_divergence(
        student_logits=student_logits,
        teacher_soft_targets=teacher_soft_targets,
        labels_attention_mask=labels_attention_mask
    )
    print(f"KL Divergence Loss: {kl_loss.item()}")

    # Verify gradient computation
    kl_loss.backward()
    print("Gradient for student logits computed.")
    assert student_logits.grad is not None, "Gradient not computed for student_logits"
    print("SafetyTeacher and KL divergence test complete.")
