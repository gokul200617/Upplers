import os
import json
import random
from collections import defaultdict
from datasets import load_dataset, Dataset
import numpy as np

# --- Configuration ---
DATA_DIR = "data"
UNIFIED_DATA_PATH = os.path.join(DATA_DIR, "unified_dataset.jsonl")
TRAIN_DATA_PATH = os.path.join(DATA_DIR, "train_dataset.jsonl")
DEV_DATA_PATH = os.path.join(DATA_DIR, "dev_dataset.jsonl")
ALPHA_SAMPLING = 0.7 # Temperature for dataset sampling
DEV_SPLIT_RATIO = 0.1 # Ratio for development set

# --- Helper Functions ---
def save_data_card(data_card_path, metadata):
    """Saves a data card (markdown file) with dataset metadata."""
    with open(data_card_path, "w", encoding="utf-8") as f:
        f.write("# Dataset Card\n\n")
        for key, value in metadata.items():
            f.write(f"- **{key}**: {value}\n")

def valence_arousal_mapping(emotion_label):
    """
    A simplified mapping from emotion labels to valence and arousal scores.
    Scores are typically -1 (negative) to 1 (positive) for valence,
    and -1 (calm) to 1 (excited) for arousal.
    These are illustrative and can be refined with more granular data.
    """
    mapping = {
        # Valence: Negative (-1) to Positive (1)
        # Arousal: Calm (-1) to Excited (1)
        "anger": {"valence": -0.8, "arousal": 0.7},
        "disgust": {"valence": -0.7, "arousal": 0.4},
        "fear": {"valence": -0.9, "arousal": 0.8},
        "joy": {"valence": 0.9, "arousal": 0.8},
        "neutral": {"valence": 0.0, "arousal": 0.0},
        "sadness": {"valence": -0.9, "arousal": -0.5},
        "surprise": {"valence": 0.5, "arousal": 0.6},
        "anticipation": {"valence": 0.6, "arousal": 0.5},
        "trust": {"valence": 0.7, "arousal": -0.3},
        "love": {"valence": 0.8, "arousal": 0.6},
        "optimism": {"valence": 0.7, "arousal": 0.4},
        "amusement": {"valence": 0.8, "arousal": 0.7},
        "excitement": {"valence": 0.8, "arousal": 0.9},
        "gratitude": {"valence": 0.7, "arousal": 0.3},
        "relief": {"valence": 0.6, "arousal": -0.2},
        "caring": {"valence": 0.6, "arousal": 0.2},
        "desire": {"valence": 0.5, "arousal": 0.6},
        "pride": {"valence": 0.7, "arousal": 0.5},
        "admiration": {"valence": 0.7, "arousal": 0.3},
        "annoyance": {"valence": -0.6, "arousal": 0.5},
        "confusion": {"valence": -0.3, "arousal": 0.1},
        "curiosity": {"valence": 0.3, "arousal": 0.4},
        "disappointment": {"valence": -0.7, "arousal": -0.4},
        "embarrassment": {"valence": -0.5, "arousal": 0.3},
        "grief": {"valence": -0.8, "arousal": -0.6},
        "nervousness": {"valence": -0.6, "arousal": 0.6},
        "remorse": {"valence": -0.7, "arousal": -0.3},
        "shame": {"valence": -0.7, "arousal": -0.4},
        "approval": {"valence": 0.6, "arousal": 0.1},
        "realization": {"valence": 0.2, "arousal": 0.3},
        "reflection": {"valence": 0.1, "arousal": -0.1},
        "calmness": {"valence": 0.4, "arousal": -0.7},
        "peace": {"valence": 0.7, "arousal": -0.8},
        # Add more as needed
    }
    return mapping.get(emotion_label.lower(), {"valence": 0.0, "arousal": 0.0})

# --- Dataset Preprocessing Functions ---

def preprocess_empathetic_dialogues():
    """Downloads and preprocesses the EmpatheticDialogues dataset."""
    print("Processing EmpatheticDialogues...")
    dataset = load_dataset("empathetic_dialogues")
    processed_data = []

    for split in ["train", "validation", "test"]:
        for example in dataset[split]:
            dialogue = example["utterances"]
            # Each turn in the dialogue is a response from either speaker.
            # We assume alternating turns between user and assistant.
            # We'll take pairs of (context, assistant_target).
            for i in range(0, len(dialogue) - 1, 2):
                context = dialogue[i] # User utterance
                assistant_target = dialogue[i+1] # Assistant response

                # EmpatheticDialogues doesn't have explicit emotion/strategy/VA labels.
                # We can infer basic emotion from the context or target if possible,
                # or use "neutral" as a placeholder. For strategy, "support" is a reasonable default.
                # Valence/arousal will be based on a simplified mapping.
                emotion_label = example.get("speaker_emotion_label", "neutral") # Assuming this field might exist or be derived
                strategy_label = "support" # Placeholder

                va_scores = valence_arousal_mapping(emotion_label)

                processed_data.append({
                    "context": context,
                    "assistant_target": assistant_target,
                    "emotion_label": emotion_label,
                    "strategy_label": strategy_label,
                    "valence": va_scores["valence"],
                    "arousal": va_scores["arousal"],
                    "dataset_id": "empathetic_dialogues",
                })
    return processed_data

def preprocess_esconv():
    """Downloads and preprocesses the ESConv dataset."""
    print("Processing ESConv...")
    dataset = load_dataset("declare-lab/esconv")
    processed_data = []

    for split in ["train", "validation", "test"]:
        for example in dataset[split]:
            dialogue = example["dialog"]
            # ESConv has 'utterance', 'speaker', 'emotion', 'strategy' for each turn.
            # We need to construct context and assistant_target.
            # Assuming 'User' and 'System' speakers.
            for i in range(len(dialogue) - 1):
                if dialogue[i]["speaker"] == "User" and dialogue[i+1]["speaker"] == "System":
                    context = dialogue[i]["utterance"]
                    assistant_target = dialogue[i+1]["utterance"]
                    emotion_label = dialogue[i]["emotion"] # Emotion of the user's turn
                    strategy_label = dialogue[i+1]["strategy"] # Strategy used by the system

                    va_scores = valence_arousal_mapping(emotion_label)

                    processed_data.append({
                        "context": context,
                        "assistant_target": assistant_target,
                        "emotion_label": emotion_label,
                        "strategy_label": strategy_label,
                        "valence": va_scores["valence"],
                        "arousal": va_scores["arousal"],
                        "dataset_id": "esconv",
                    })
    return processed_data

def preprocess_goemotions():
    """Downloads and preprocesses the GoEmotions dataset."""
    print("Processing GoEmotions...")
    dataset = load_dataset("go_emotions", "simplified")
    processed_data = []

    # GoEmotions provides text and labels. We need to frame this for chatbot training.
    # It's primarily for emotion classification, so we'll need to create a dummy assistant_target.
    # For simplicity, we can imagine the assistant responding with a neutral acknowledgement or asking a follow-up.
    # We'll also assign a simple strategy.
    emotion_labels_map = dataset["train"].features["labels"].feature.names


    for split in ["train", "validation", "test"]:
        for example in dataset[split]:
            context = example["text"]
            # GoEmotions has multiple labels, we'll take the first one or a simplified one.
            emotion_id = example["labels"][0] if example["labels"] else 27 # 27 is 'neutral'
            emotion_label = emotion_labels_map[emotion_id]

            assistant_target = "I understand how you feel." # A generic empathetic response
            strategy_label = "acknowledgement" # Simple placeholder strategy

            va_scores = valence_arousal_mapping(emotion_label)

            processed_data.append({
                "context": context,
                "assistant_target": assistant_target,
                "emotion_label": emotion_label,
                "strategy_label": strategy_label,
                "valence": va_scores["valence"],
                "arousal": va_scores["arousal"],
                "dataset_id": "goemotions",
            })
    return processed_data

# --- Unification and Sampling ---

def unify_datasets(empathetic_dialogues_data, esconv_data, goemotions_data):
    """Unifies all processed datasets into a single list."""
    print("Unifying datasets...")
    unified = empathetic_dialogues_data + esconv_data + goemotions_data
    random.shuffle(unified)
    return unified

def temperature_based_sampling_split(unified_data, alpha=ALPHA_SAMPLING, dev_ratio=DEV_SPLIT_RATIO):
    """
    Splits the unified dataset into train and dev sets using temperature-based sampling.
    p_i = n_i^α / Σ n_j^α, with α configurable.
    """
    print(f"Splitting data with temperature-based sampling (alpha={alpha})...")
    dataset_counts = defaultdict(int)
    for item in unified_data:
        dataset_counts[item["dataset_id"]] += 1

    dataset_ids = list(dataset_counts.keys())
    # Calculate sampling probabilities
    # n_i^α
    weighted_counts = {ds_id: count**alpha for ds_id, count in dataset_counts.items()}
    # Σ n_j^α
    total_weighted_count = sum(weighted_counts.values())
    # p_i = n_i^α / Σ n_j^α
    sampling_probs = {ds_id: weighted_counts[ds_id] / total_weighted_count for ds_id in dataset_ids}

    train_data = []
    dev_data = []

    # Allocate development set first to ensure representation
    dev_indices = set()
def generate_preference_dataset(unified_data, output_path, num_pairs=1000):
    """
    Generates a synthetic preference dataset for DPO training.
    For each (context, assistant_target) pair, it generates a 'rejected' response
    by making the assistant_target less empathetic or slightly off-topic/generic.
    """
    print("Generating synthetic preference dataset...")
    preference_data = []
    random.shuffle(unified_data)

    for item in tqdm(unified_data[:num_pairs], desc="Generating DPO pairs"):
        context = item["context"]
        chosen_response = item["assistant_target"]

        # Simple heuristic to generate a 'rejected' response:
        # 1. Truncate the chosen response.
        # 2. Replace empathetic phrases with neutral/generic ones.
        # 3. Add a slightly irrelevant or less helpful statement.
        
        rejected_response = chosen_response

        # Heuristic 1: Truncate
        if len(rejected_response) > 50 and random.random() < 0.5:
            rejected_response = rejected_response[:random.randint(20, 50)] + "..."
        
        # Heuristic 2: Replace empathetic phrases (very basic, can be expanded)
        replacements = {
            "I understand": "Okay",
            "I'm here for you": "I'm listening",
            "I'm sorry to hear that": "That's tough",
            "How can I help": "What's next",
            "It sounds like you feel": "So you feel",
        }
        for old, new in replacements.items():
            if old in rejected_response and random.random() < 0.3:
                rejected_response = rejected_response.replace(old, new, 1)

        # Heuristic 3: Add a generic/less helpful ending
        generic_endings = [
            "Anyway.",
            "Moving on.",
            "Got it.",
            "Hmm.",
            "Is there anything else?",
        ]
        if random.random() < 0.2:
            rejected_response += " " + random.choice(generic_endings)

        # Ensure chosen and rejected are different
        if chosen_response == rejected_response:
            # If by chance they are the same, try a more aggressive truncation
            if len(chosen_response) > 30:
                rejected_response = chosen_response[:random.randint(10, 20)] + ".."
            else:
                rejected_response = "I heard you." # Fallback to a very generic response

        preference_data.append({
            "context": context,
            "chosen": chosen_response,
            "rejected": rejected_response,
            "dataset_id": "synthetic_dpo_pair",
        })

    with open(output_path, "w", encoding="utf-8") as f:
        for item in preference_data:
            f.write(json.dumps(item) + "\n")



    # 6. Generate Preference Dataset for DPO (after SFT is conceptually done)
    generate_preference_dataset(unified_data, os.path.join(DATA_DIR, "preference_dataset.jsonl"))
    print(f"Preference dataset generated and saved to {os.path.join(DATA_DIR, "preference_dataset.jsonl")}")
